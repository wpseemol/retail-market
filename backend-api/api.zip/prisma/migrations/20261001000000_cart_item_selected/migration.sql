-- AlterTable
ALTER TABLE `cart_items` ADD COLUMN `selected` BOOLEAN NOT NULL DEFAULT true;
