import { z } from "zod";
import { isAvatarPresetId } from "../lib/avatarPresets.js";
import { normalizePhone, PHONE_FORMAT_MESSAGE } from "../lib/phone.js";

const HTML_TAG_RE = /<\s*\/?\s*[a-zA-Z!][^>]*>/;
const SCRIPT_TAG_RE = /<\s*\/?\s*script\b/i;
const PHP_TAG_RE = /<\?(?:php|=)?|\?>/i;
const JS_PROTOCOL_RE = /javascript\s*:/i;
const EVENT_HANDLER_RE = /\bon[a-z]+\s*=/i;
const JS_CODE_RE =
  /(\beval\s*\()|(\bFunction\s*\()|(\bnew\s+Function\b)|(\bimport\s*\()|(\brequire\s*\()|(\bdocument\.(cookie|write|location)\b)|(\bwindow\.(location|eval)\b)|(\batob\s*\()|(\bfromCharCode\b)/i;
const PHP_CODE_RE =
  /(\bbase64_decode\s*\()|(\bsystem\s*\()|(\bshell_exec\s*\()|(\bpassthru\s*\()|(\bexec\s*\()|(\bpreg_replace\s*\([^)]*\/e)/i;

/** Compound SQL payloads — avoids blocking normal passwords that contain `'`, `"`, or `;`. */
const SQL_INJECTION_RE =
  /(\bunion\s+select\b)|(\bselect\b.+\bfrom\b)|(\binsert\s+into\b)|(\bdelete\s+from\b)|(\bdrop\s+(table|database)\b)|(\balter\s+table\b)|(\btruncate\s+table\b)|(\b(exec|execute)\s*\()|(\bxp_\w+\b)|(\b(or|and)\b\s+\d+\s*=\s*\d+)|(;\s*(select|insert|update|delete|drop|alter|truncate)\b)|(\/\*|\*\/)|(--\s+)/i;

/** Reject HTML/script/PHP tags, JS/PHP code payloads, and common SQL-injection / XSS. */
export function findUnsafeInputReason(value: string): string | null {
  if (SCRIPT_TAG_RE.test(value)) {
    return "Script tags are not allowed";
  }
  if (PHP_TAG_RE.test(value) || PHP_CODE_RE.test(value)) {
    return "PHP code is not allowed";
  }
  if (JS_CODE_RE.test(value)) {
    return "JavaScript code is not allowed";
  }
  if (
    HTML_TAG_RE.test(value) ||
    JS_PROTOCOL_RE.test(value) ||
    EVENT_HANDLER_RE.test(value)
  ) {
    return "HTML tags and event handlers are not allowed";
  }
  if (SQL_INJECTION_RE.test(value)) {
    return "SQL-like patterns are not allowed";
  }
  return null;
}

/** Apply injection/XSS guards to any string body field from the frontend. */
export function withSafeInput<T extends z.ZodType<string>>(schema: T) {
  return schema.superRefine((value, ctx) => {
    const reason = findUnsafeInputReason(value);
    if (reason) {
      ctx.addIssue({ code: "custom", message: reason });
    }
  });
}

const safeTrimmed = (min: number, max: number) =>
  withSafeInput(z.string().trim().min(min).max(max));

/** Required phone → normalized E.164 (`+8801712345678`). */
export const phoneField = withSafeInput(z.string().trim().min(1).max(30)).transform(
  (value, ctx) => {
    const normalized = normalizePhone(value);
    if (!normalized) {
      ctx.addIssue({ code: "custom", message: PHONE_FORMAT_MESSAGE });
      return z.NEVER;
    }
    return normalized;
  },
);

const safeOptionalPhone = z
  .union([z.literal(""), phoneField])
  .optional()
  .transform((value) => value || undefined);

export const registerSchema = z.object({
  first_name: safeTrimmed(1, 100),
  last_name: safeTrimmed(1, 100),
  email: withSafeInput(z.string().trim().email().max(255)),
  password: withSafeInput(z.string().min(8).max(128)),
  phone: safeOptionalPhone,
});

export const loginSchema = z.object({
  email: withSafeInput(z.string().trim().email().max(255)),
  password: withSafeInput(z.string().min(1).max(128)),
});

const jwtShape = (invalidMessage: string) =>
  z
    .string()
    .trim()
    .min(20)
    .max(4096)
    .regex(/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/, invalidMessage);

export const refreshSchema = z.object({
  refreshToken: withSafeInput(jwtShape("Invalid refresh token format")),
});

/** Google Sign-In — GIS ID token and/or OAuth access token from the popup. */
export const googleAuthSchema = z
  .object({
    idToken: z.string().trim().min(20).max(8192).optional(),
    accessToken: z.string().trim().min(20).max(8192).optional(),
  })
  .refine((data) => Boolean(data.idToken || data.accessToken), {
    message: "idToken or accessToken is required",
  });

/** Facebook Login — user access token from the JS SDK popup. */
export const facebookAuthSchema = z.object({
  accessToken: z
    .string()
    .trim()
    .min(20)
    .max(4096)
    .regex(/^[A-Za-z0-9_.|-]+$/, "Invalid Facebook token format"),
});

/** Sign in with Apple — `id_token` JWT; name only arrives on first consent. */
export const appleAuthSchema = z.object({
  idToken: jwtShape("Invalid Apple token format"),
  firstName: safeTrimmed(1, 100).optional(),
  lastName: safeTrimmed(1, 100).optional(),
});

export const updateProfileSchema = z
  .object({
    first_name: safeTrimmed(1, 100).optional(),
    last_name: safeTrimmed(1, 100).optional(),
    phone: z
      .union([z.string(), z.null()])
      .optional()
      .transform((value, ctx) => {
        if (value === undefined) return undefined;
        if (value === null) return null;
        const trimmed = value.trim();
        if (!trimmed) return null;
        const reason = findUnsafeInputReason(trimmed);
        if (reason) {
          ctx.addIssue({ code: "custom", message: reason });
          return z.NEVER;
        }
        const normalized = normalizePhone(trimmed);
        if (!normalized) {
          ctx.addIssue({ code: "custom", message: PHONE_FORMAT_MESSAGE });
          return z.NEVER;
        }
        return normalized;
      }),
    gender: z
      .union([z.enum(["male", "female", "other"]), z.null(), z.literal("")])
      .optional()
      .transform((value) => {
        if (value === undefined) return undefined;
        if (value === null || value === "") return null;
        return value;
      }),
    date_of_birth: z
      .union([z.string(), z.null(), z.literal("")])
      .optional()
      .transform((value, ctx) => {
        if (value === undefined) return undefined;
        if (value === null || value === "") return null;
        const trimmed = value.trim();
        const reason = findUnsafeInputReason(trimmed);
        if (reason) {
          ctx.addIssue({ code: "custom", message: reason });
          return z.NEVER;
        }
        if (!/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) {
          ctx.addIssue({ code: "custom", message: "Invalid date format" });
          return z.NEVER;
        }
        const parsed = new Date(`${trimmed}T00:00:00.000Z`);
        if (Number.isNaN(parsed.getTime())) {
          ctx.addIssue({ code: "custom", message: "Invalid date" });
          return z.NEVER;
        }
        return trimmed;
      }),
    /** Allowlisted built-in SVG key, or `null` to clear. Clears uploaded `avatar_id`. */
    avatar_preset: z
      .union([z.string(), z.null()])
      .optional()
      .transform((value, ctx) => {
        if (value === undefined) return undefined;
        if (value === null || value === "") return null;
        const trimmed = String(value).trim();
        const reason = findUnsafeInputReason(trimmed);
        if (reason) {
          ctx.addIssue({ code: "custom", message: reason });
          return z.NEVER;
        }
        if (!isAvatarPresetId(trimmed)) {
          ctx.addIssue({ code: "custom", message: "Invalid avatar preset" });
          return z.NEVER;
        }
        return trimmed;
      }),
  })
  .refine(
    (data) =>
      data.first_name !== undefined ||
      data.last_name !== undefined ||
      data.phone !== undefined ||
      data.gender !== undefined ||
      data.date_of_birth !== undefined ||
      data.avatar_preset !== undefined,
    { message: "At least one field is required" },
  );

export const sendPhoneCodeSchema = z
  .object({
    /** Optional: verify a new number (saved to the profile only after the code is confirmed). */
    phone: phoneField.optional(),
    /**
     * Delivery channel for the OTP. `whatsapp` uses the configured WhatsApp gateway
     * (Meta Cloud / Twilio); confirm still uses the same phone verification flow.
     * Default `sms`. Rejects any other string (no coercion from truthy junk).
     */
    via: z.enum(["sms", "whatsapp"]).optional().default("sms"),
  })
  .strict();

export const confirmCodeSchema = z.object({
  code: z
    .string()
    .trim()
    .regex(/^\d{6}$/, "Enter the 6-digit code"),
});

/**
 * Set or change storefront password.
 * Social accounts without a password may omit `current_password`.
 * Email accounts must send the current password.
 */
export const setPasswordSchema = z
  .object({
    current_password: withSafeInput(z.string().min(1).max(128)).optional(),
    new_password: withSafeInput(z.string().min(8).max(128)),
    confirm_password: withSafeInput(z.string().min(8).max(128)),
  })
  .strict()
  .superRefine((data, ctx) => {
    if (data.new_password !== data.confirm_password) {
      ctx.addIssue({
        code: "custom",
        message: "Passwords do not match",
        path: ["confirm_password"],
      });
    }
    if (
      data.current_password !== undefined &&
      data.current_password === data.new_password
    ) {
      ctx.addIssue({
        code: "custom",
        message: "New password must be different from the current password",
        path: ["new_password"],
      });
    }
  });

export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type RefreshInput = z.infer<typeof refreshSchema>;
export type GoogleAuthInput = z.infer<typeof googleAuthSchema>;
export type UpdateProfileInput = z.infer<typeof updateProfileSchema>;
export type SetPasswordInput = z.infer<typeof setPasswordSchema>;
