import type { Media, User } from "@prisma/client";
import { env } from "./env.js";
import { publicObjectUrl } from "./storage/files.js";
import { isTwoFactorEnabled, roleRequiresTwoFactor } from "./totp.js";

export type UserWithAvatar = User & { avatar?: Media | null };

/** Prisma include for auth responses that expose the public user. */
export const userWithAvatarInclude = {
  avatar: true,
} as const;

export function mediaPublicUrl(media: Pick<Media, "disk" | "file_path" | "file_name">): string {
  const remote = publicObjectUrl(media.disk, media.file_path, media.file_name);
  if (remote) return remote;
  const relative = `/uploads/${media.file_path.replace(/^\/+|\/+$/g, "")}/${media.file_name}`;
  return `${env.publicBaseUrl}${relative}`;
}

export function toPublicMedia(media: Media | null | undefined) {
  if (!media) return null;
  return {
    id: media.id.toString(),
    disk: media.disk,
    file_name: media.file_name,
    original_name: media.original_name,
    file_path: media.file_path,
    path: mediaPublicUrl(media),
    file_size: media.file_size?.toString() ?? null,
    mime_type: media.mime_type,
    dimensions: media.dimensions,
    alt_text: media.alt_text,
    collection_name: media.collection_name,
    is_public: media.is_public,
    sort_order: media.sort_order,
  };
}

export function toPublicUser(user: UserWithAvatar) {
  return {
    id: user.id.toString(),
    first_name: user.first_name,
    last_name: user.last_name,
    username: user.username,
    email: user.email,
    phone: user.phone,
    role: user.role,
    status: user.status,
    gender: user.gender,
    date_of_birth: user.date_of_birth,
    email_verified_at: user.email_verified_at,
    phone_verified_at: user.phone_verified_at,
    provider_name: user.provider_name,
    /** True when a local password is set (email login and/or social + password). */
    has_password: Boolean(user.password),
    /** Authenticator 2FA is confirmed. Never exposes the secret. */
    two_factor_enabled: isTwoFactorEnabled(user),
    /** True only when role is in TWO_FACTOR_REQUIRED_ROLES (currently none — optional for all staff). */
    two_factor_required: roleRequiresTwoFactor(user.role),
    avatar_id: user.avatar_id?.toString() ?? null,
    avatar_preset: user.avatar_preset ?? null,
    last_login_at: user.last_login_at,
    created_at: user.created_at,
    updated_at: user.updated_at,
    avatar: toPublicMedia(user.avatar),
  };
}
